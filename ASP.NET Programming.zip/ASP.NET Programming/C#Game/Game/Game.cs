﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Game : Form
    {
        public Game()
        {
            InitializeComponent();
        }

        public object Interaction { get; private set; }

        private void btnLevel1_Click(object sender, EventArgs e)
        {
            int[] numbers = new int[10];
            for(int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = i;
            }

            string numbersString = "";
            for(int i = 0;i < numbers.Length; i++)
            {
                numbersString += numbers[i] + " ";
            }
            MessageBox.Show(numbersString, "Numbers Test");
        }

        private void btnLevel2_Click(object sender, EventArgs e)
        {
            decimal[] totals = new decimal[4] {14.95m, 12.95m, 11.95m, 9.95m};
            string totalsString = "";
            decimal sum = 0;
            decimal average = 0;

            /*for loop*/

            /*for (int i = 0; i < totals.Length; i++)
                totalsString += totals[i] + "\n";

            for (int i = 0; i < totals.Length; i++)
            {
                sum += totals[i];
            }
            average = sum / totals.Length;
            MessageBox.Show("The totals are :\n" + totalsString + "\n" +
                "Sum: " + sum + "\n" +
                "Average: " + average, "Totals Test");*/

            /*foreach*/

            foreach(decimal total in totals)
            {
                totalsString += total + "\n";
            }

            foreach(decimal total in totals)
            {
                sum += total;
            }
            average = sum / totals.Length;
            MessageBox.Show("The totals are :\n" + totalsString + "\n" +
                "Sum: " + sum + "\n" +
                "Average: " + average, "Totals Test");
        }

        private void btnLevel3_Click(object sender, EventArgs e)
        {
            int[,] numbers = new int[3, 2];
            int value = 1;
            int count = 0;
            string numbersString = "";

            /*for loop*/

            // set values to array
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbers[i, j] = value++;
                }
            }
            // read array
            /*for (int i = 0;i<numbers.GetLength(0);i++)
            {
                for(int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbersString += numbers[i,j] + " ";
                }
                numbersString += "\n";
            }*/

            /*foreach*/
            // read array
            foreach(int number in numbers)
            {
                numbersString += number + " ";
                count++;
                if (count == 2)
                {
                    numbersString += "\n";
                    count = 0;
                }
            }

            MessageBox.Show(numbersString, "Numbers Test");
        }
    }
}
