﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BugTroble
{
    public partial class frmBugTrouble : Form
    {
        public frmBugTrouble()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double volumeOfHouse = Convert.ToDouble(txtVolumeOfYourHouse.Text);
            double numberOfRoaches = Convert.ToDouble(txtNumberOfRoachesInYourHouse.Text);
            int weeks = Convert.ToInt32(txtWeeksUntilHouseIsFull.Text);

            double numberTotalOfRoaches = 0;

            double roachVolume = 0.002; // Each roach is 0.002 cubic feet
            double growthRate = 1.95; // Weekly growth rate of 95%

            while(weeks > 0 && volumeOfHouse > numberOfRoaches * roachVolume)
            {
                numberOfRoaches *= growthRate;
                numberTotalOfRoaches += numberOfRoaches;
                weeks--;
            }
            txtTotalNumberOfRoaches.Text = numberTotalOfRoaches.ToString();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
