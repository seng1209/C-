﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentPopulation
{
    public partial class frmStudentPupolation : Form
    {
        public frmStudentPupolation()
        {
            InitializeComponent();
        }
        private void btnProject_Click(object sender, EventArgs e)
        {
            double numberOfStudentToday = Convert.ToInt32(txtNumberOfStudentToday.Text);
            double annualGrowthRate = Convert.ToDouble(txtAunnalGrowthRate.Text);
            int numberOfYears = Convert.ToInt32(txtNumberOfYear.Text);
            double projectNumberOfStudents = 0;
            int i = 1;
            double rate = annualGrowthRate + 1;
            double result = 1.0;

            // using while loop
            /*while (i <= numberOfYears)
            {
                result *= rate;
                i++;
            }
            projectNumberOfStudents = numberOfStudentToday * result;
            */

            // using pow method
            // double projectNumberOfStudents = numberOfStudentToday * Math.Pow(annualGrowthRate, numberOfYears);

            // using for loop
            for (i = 1; i <= numberOfYears; i++)
            {
                result *= rate;
            }

            projectNumberOfStudents = numberOfStudentToday * result;

            txtNumberOfStudentToday.Text = numberOfStudentToday.ToString();
            txtAunnalGrowthRate.Text = annualGrowthRate.ToString();
            txtNumberOfYear.Text = numberOfYears.ToString();
            txtProject.Text = projectNumberOfStudents.ToString();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNumberOfYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                double numberOfStudentToday = Convert.ToInt32(txtNumberOfStudentToday.Text);
                double annualGrowthRate = Convert.ToDouble(txtAunnalGrowthRate.Text);
                int numberOfYears = Convert.ToInt32(txtNumberOfYear.Text);
                double projectNumberOfStudents = 0;
                int i = 1;
                double rate = annualGrowthRate + 1;
                double result = 1.0;

                // using while loop
                /*while (i <= numberOfYears)
                {
                    result *= rate;
                    i++;
                }
                projectNumberOfStudents = numberOfStudentToday * result;
                */

                // using pow method
                // double projectNumberOfStudents = numberOfStudentToday * Math.Pow(annualGrowthRate, numberOfYears);

                // using for loop
                for (i = 1; i <= numberOfYears; i++)
                {
                    result *= rate;
                }

                projectNumberOfStudents = numberOfStudentToday * result;

                txtNumberOfStudentToday.Text = numberOfStudentToday.ToString();
                txtAunnalGrowthRate.Text = annualGrowthRate.ToString();
                txtNumberOfYear.Text = numberOfYears.ToString();
                txtProject.Text = projectNumberOfStudents.ToString();
            }
            else if(e.KeyChar== (char)Keys.Escape)
            {
                this.Close();
            }
        }
    }
}
