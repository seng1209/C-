﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace SippingandHandling
{
    public partial class frmSippingandHandling : Form
    {
        public frmSippingandHandling()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal orderTotal = Convert.ToDecimal(txtOrderTotal.Text); // convert string to decimal
            string customerType = txtCustomerType.Text; // convert string to decimal
            decimal shippingCosts = 0m;
            decimal salesTax = 0m;
            if (customerType == "P" || customerType == "p")
            {
                salesTax = .07m;
                txtSipping.Text = shippingCosts.ToString("c");
                txtSalesTax.Text = (orderTotal * salesTax).ToString("c");
                txtGrandTotal.Text = (orderTotal + (orderTotal * salesTax)).ToString("c");
            }
            else if(customerType == "N" || customerType == "n")
            {
                if (orderTotal >= 0m && orderTotal == 25.00m)
                {
                    shippingCosts = 5.00m;
                }
                else if(orderTotal >= 25.01m && orderTotal <= 500.00m)
                {
                    shippingCosts = 8.00m;
                }
                else if(orderTotal >= 500.01m && orderTotal <= 1000.00m)
                {
                    shippingCosts = 10.00m;
                }
                else if (orderTotal >= 1000.01m && orderTotal <= 5000.00m)
                {
                    shippingCosts = 15.00m;
                }
                else if(orderTotal >= 5000.01m)
                {
                    shippingCosts = 25.00m;
                }
                else
                {
                    MessageBox.Show("Worng number " + orderTotal);
                }
                salesTax = orderTotal * .07m;
                salesTax += shippingCosts;
                txtOrderTotal.Text = orderTotal.ToString();
                txtCustomerType.Text = customerType.ToString();
                txtSipping.Text = shippingCosts.ToString("c");
                txtSalesTax.Text = salesTax.ToString("c");
                txtGrandTotal.Text = (orderTotal + salesTax).ToString("c");
            }
            else
            {
                MessageBox.Show("Customers Type is wrong " + customerType);
            }
            txtOrderTotal.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCustomerType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                decimal orderTotal = Convert.ToDecimal(txtOrderTotal.Text); // convert string to decimal
                string customerType = txtCustomerType.Text; // convert string to decimal
                decimal shippingCosts = 0m;
                decimal salesTax = 0m;
                if (customerType == "P" || customerType == "p")
                {
                    salesTax = .07m;
                    txtSipping.Text = shippingCosts.ToString("c");
                    txtSalesTax.Text = (orderTotal * salesTax).ToString("c");
                    txtGrandTotal.Text = (orderTotal + (orderTotal * salesTax)).ToString("c");
                }
                else if (customerType == "N" || customerType == "n")
                {
                    if (orderTotal >= 0m && orderTotal == 25.00m)
                    {
                        shippingCosts = 5.00m;
                    }
                    else if (orderTotal >= 25.01m && orderTotal <= 500.00m)
                    {
                        shippingCosts = 8.00m;
                    }
                    else if (orderTotal >= 500.01m && orderTotal <= 1000.00m)
                    {
                        shippingCosts = 10.00m;
                    }
                    else if (orderTotal >= 1000.01m && orderTotal <= 5000.00m)
                    {
                        shippingCosts = 15.00m;
                    }
                    else if (orderTotal >= 5000.01m)
                    {
                        shippingCosts = 25.00m;
                    }
                    else
                    {
                        MessageBox.Show("Worng number " + orderTotal);
                    }
                    salesTax = orderTotal * .07m;
                    salesTax += shippingCosts;
                    txtOrderTotal.Text = orderTotal.ToString();
                    txtCustomerType.Text = customerType.ToString();
                    txtSipping.Text = shippingCosts.ToString("c");
                    txtSalesTax.Text = salesTax.ToString("c");
                    txtGrandTotal.Text = (orderTotal + salesTax).ToString("c");
                }
                else
                {
                    MessageBox.Show("Customers Type is wrong " + customerType);
                }
                txtOrderTotal.Focus();
            }
            else if(e.KeyChar== (char)Keys.Escape)
            {
                this.Close();
            }
        }
    }
}
