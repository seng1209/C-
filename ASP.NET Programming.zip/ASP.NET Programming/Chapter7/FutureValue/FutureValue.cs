﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FutureValue
{
    public partial class frmFutureValue : Form
    {
        public frmFutureValue()
        {
            InitializeComponent();
        }
        private decimal CalculateFutureValue(decimal monthlyInvestment, decimal monthlyInterestRate,
            int months)
        {
            decimal futureValue = 0m;
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + monthlyInvestment) * (1 + monthlyInterestRate);
            }
            return futureValue;
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    decimal monthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
                    if (monthlyInvestment <= 0)
                    {
                        MessageBox.Show(
                            "Monthly Investment must be greater than 0.",
                            "Entry Error");
                        txtMonthlyInvestment.Focus();
                    }
                    else if (monthlyInvestment >= 1000)
                    {
                        MessageBox.Show(
                            "Monthly Investment must be less than 1,000.",
                            "Entry Error");
                        txtMonthlyInvestment.Focus();
                    }
                    decimal yearlyInterestRate = Convert.ToDecimal(txtInterestRate.Text);
                    int years = Convert.ToInt32(txtYears.Text);

                    int months = years * 12;
                    decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;
                    decimal futureValue = CalculateFutureValue(monthlyInvestment, monthlyInterestRate, months);

                    txtFutureValue.Text = futureValue.ToString("c");
                    txtMonthlyInvestment.Focus();
                }
            }
            /*catch (FormatException)
            {
                MessageBox.Show(
                    "Invalid numeric format. " +
                    "Please check all entries.", "Entry Error");
            }
            catch (OverflowException)
            {
                MessageBox.Show(
                    "Overflow error. Please enter smaller values.",
                    "Entry Error");
            }*/
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    ex.GetType().ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtYears_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Enter)
            {
                try
                {
                    if (IsValidData())
                    {
                        decimal monthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
                        if (monthlyInvestment <= 0)
                        {
                            MessageBox.Show(
                                "Monthly Investment must be greater than 0.",
                                "Entry Error");
                            txtMonthlyInvestment.Focus();
                        }
                        else if (monthlyInvestment >= 1000)
                        {
                            MessageBox.Show(
                                "Monthly Investment must be less than 1,000.",
                                "Entry Error");
                            txtMonthlyInvestment.Focus();
                        }
                        decimal yearlyInterestRate = Convert.ToDecimal(txtInterestRate.Text);
                        int years = Convert.ToInt32(txtYears.Text);

                        int months = years * 12;
                        decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;
                        decimal futureValue = CalculateFutureValue(monthlyInvestment, monthlyInterestRate, months);

                        txtFutureValue.Text = futureValue.ToString("c");
                        txtMonthlyInvestment.Focus();
                    }
                }
                /*catch (FormatException)
                {
                    MessageBox.Show(
                        "Invalid numeric format. " +
                        "Please check all entries.", "Entry Error");
                }
                catch (OverflowException)
                {
                    MessageBox.Show(
                        "Overflow error. Please enter smaller values.",
                        "Entry Error");
                }*/
                catch (Exception ex)
                {
                    MessageBox.Show(
                        ex.Message,
                        ex.GetType().ToString());
                }
            }
            else if(e.KeyChar == (char)Keys.Escape)
            {
                this.Close();
            }
        }
        private void ClearFutureValue(object sender, EventArgs e) 
        {
            txtFutureValue.Text = "";
        }
        public bool IsPersent(TextBox textBox, string name)
        {
            if(textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.",
                    "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
        public bool IsDecimal(TextBox textBox, string name)
        {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }catch(FormatException)
            {
                MessageBox.Show(name + " must be a decimal " +
                    "value.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }
        public bool InInt32(TextBox textBox, string name)
        {
            try
            {
                Convert.ToInt32(textBox.Text);
                return true;
            }catch(FormatException )
            {
                MessageBox.Show(name + " must be an integer.",
                    "Entry Error");
                textBox.Focus();
                return false;
            }
        }
        public bool IsWithinRange(TextBox textBox, string name, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if(number < min || number > max)
            {
                MessageBox.Show(name + " must be between " + 
                    min.ToString() + " and "+ max.ToString() + 
                    ".", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
        public bool IsValidData()
        {
            return  IsPersent(txtMonthlyInvestment, "Monthly Investment") &&
                    IsDecimal(txtMonthlyInvestment, "Monthly Investment") &&
                    IsWithinRange(txtMonthlyInvestment, "Monthly Investment", 1, 1000) &&
                    IsPersent(txtInterestRate, "Interest Rate") &&
                    IsDecimal(txtInterestRate, "Interest Rate") &&
                    IsWithinRange(txtInterestRate, "Interest Rate", 1, 20) &&
                    IsPersent(txtYears, "Number of Years") &&
                    InInt32(txtYears, "Number of Years") &&
                    IsWithinRange(txtYears, "Number of Years", 1, 40);
            /*// Validate the Monthly Investment text box
            if(!IsPersent(txtMonthlyInvestment, "Monthly Investment"))
                return false;
            if(!IsDecimal(txtMonthlyInvestment, "Monthly Investment"))
                return false;
            if (!IsWithinRange(txtMonthlyInvestment, "Monthly Investment", 1, 1000))
                return false;

            // Validate the Interest Rate text box
            if (!IsPersent(txtInterestRate, "Interest Rate"))
                return false;
            if (!IsDecimal(txtInterestRate, "Interest Rate"))
                return false;
            if (!IsWithinRange(txtInterestRate, "Interest Rate", 1, 1000))
                return false;

            return true;*/
        }
    }
}
